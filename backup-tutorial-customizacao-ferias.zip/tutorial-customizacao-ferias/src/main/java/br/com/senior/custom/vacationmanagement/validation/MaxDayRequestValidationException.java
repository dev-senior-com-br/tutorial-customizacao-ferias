package br.com.senior.custom.vacationmanagement.validation;

public class MaxDayRequestValidationException extends RuntimeException {

    /**
     * Lança uma exceção com uma mensagem de erro
     *
     * @param message Mensagem de erro
     */
    MaxDayRequestValidationException(String message) {
        super(message);
    }

    /**
     * Lança uma exceção com uma mensagem e uma causa
     *
     * @param message Mensagem de erro
     * @param cause Causa do erro
     */
    MaxDayRequestValidationException(String message, Throwable cause) {
        super(message, cause);
    }

}
