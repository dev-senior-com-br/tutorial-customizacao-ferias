package br.com.senior.custom.vacationmanagement.vacationpolicy;

public class GetVacationPolicyByEmployeeOutput {

    /**
     * Política de férias
     */
    public VacationPolicy vacationPolicy;

}
