package br.com.senior.custom.vacationmanagement.validation;

import java.util.List;

import br.com.senior.custom.vacationmanagement.vacationschedule.VacationSchedule;

public class ValidateVacationScheduleInput {

    /**
     * Solicitações de férias
     */
    public List<VacationSchedule> vacationSchedules;
    
}
