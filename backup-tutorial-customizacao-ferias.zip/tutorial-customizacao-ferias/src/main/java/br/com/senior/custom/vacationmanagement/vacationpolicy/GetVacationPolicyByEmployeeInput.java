package br.com.senior.custom.vacationmanagement.vacationpolicy;

public class GetVacationPolicyByEmployeeInput {

    /**
     * Id do colaborador
     */
    public String employeeId;

}
