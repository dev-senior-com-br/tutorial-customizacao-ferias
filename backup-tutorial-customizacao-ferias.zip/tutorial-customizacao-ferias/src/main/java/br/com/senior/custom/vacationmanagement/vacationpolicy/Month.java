package br.com.senior.custom.vacationmanagement.vacationpolicy;

/**
 * Mês
 */
public enum Month {
    /**
     * Janeiro
     */
    JANUARY,

    /**
     * Fevereiro
     */
    FEBRUARY,

    /**
     * Março
     */
    MARCH,

    /**
     * Abril
     */
    APRIL,

    /**
     * Maio
     */
    MAY,

    /**
     * Junho
     */
    JUNE,

    /**
     * Julho
     */
    JULY,

    /**
     * Agosto
     */
    AUGUST,

    /**
     * Setembro
     */
    SEPTEMBER,

    /**
     * Outubro
     */
    OCTOBER,

    /**
     * Novembro
     */
    NOVEMBER,

    /**
     * Dezembro
     */
    DECEMBER
}
