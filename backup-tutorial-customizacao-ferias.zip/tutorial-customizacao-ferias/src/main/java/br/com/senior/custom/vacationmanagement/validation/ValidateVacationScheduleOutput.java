package br.com.senior.custom.vacationmanagement.validation;

import java.util.List;

import br.com.senior.custom.vacationmanagement.vacationschedule.VacationScheduleMessage;

public class ValidateVacationScheduleOutput {

    /**
     * Mensagem com o erro, caso tenha ocorrido problema de validação
     */
    public List<VacationScheduleMessage> vacationScheduleMessages;
    
}
