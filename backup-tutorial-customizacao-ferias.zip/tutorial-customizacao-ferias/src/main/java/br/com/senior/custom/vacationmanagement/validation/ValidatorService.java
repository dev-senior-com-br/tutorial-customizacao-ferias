package br.com.senior.custom.vacationmanagement.validation;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import br.com.senior.custom.vacationmanagement.vacationschedule.VacationSchedule;

@Service
public class ValidatorService {

    @Inject
    private MaxDayRequestValidatorService maxDayRequestValidatorService;

    @Inject
    private StartDateValidatorService startDateValidatorService;

    /**
     * Método que irá chamar as validações customizadas
     *
     * @param output Mensagens de erro da validação da Senior
     * @param vacationSchedule Solicitação de férias
     */
    public void validate(ValidateVacationScheduleOutput output, VacationSchedule vacationSchedule) {
        maxDayRequestValidatorService.handleValidation(output, vacationSchedule);
        startDateValidatorService.handleValidation(output, vacationSchedule);
    }

}
