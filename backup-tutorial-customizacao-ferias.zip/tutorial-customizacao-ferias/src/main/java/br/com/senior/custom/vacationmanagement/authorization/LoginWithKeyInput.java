package br.com.senior.custom.vacationmanagement.authorization;

public class LoginWithKeyInput {

    public String tenantName;
    public String accessKey;
    public String secret;

}
